package com.mrdevs.talent_center_be;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TalentCenterBeApplicationTests {

	@Test
	void contextLoads() {
	}

}
