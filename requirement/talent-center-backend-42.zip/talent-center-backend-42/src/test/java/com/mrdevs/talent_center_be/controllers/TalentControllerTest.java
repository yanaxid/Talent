package com.mrdevs.talent_center_be.controllers;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.mapping.JpaMetamodelMappingContext;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.mrdevs.talent_center_be.controller.talentManagement.TalentController;
import com.mrdevs.talent_center_be.dto.request.TalentFilterRequestDTO;
import com.mrdevs.talent_center_be.dto.response.GlobalDTO;
import com.mrdevs.talent_center_be.dto.response.GlobalListDTO;
import com.mrdevs.talent_center_be.dto.response.TalentDetailResponseDTO;
import com.mrdevs.talent_center_be.dto.response.TalentResponseDTO;
import com.mrdevs.talent_center_be.model.Talent;
import com.mrdevs.talent_center_be.service.TalentService;

@WebMvcTest(TalentController.class)
@ExtendWith(MockitoExtension.class)
@MockBean(JpaMetamodelMappingContext.class)
public class TalentControllerTest {

    @Autowired
    private MockMvc mvc;

    @MockBean
    private TalentService talentService;

    private Talent talent;
    private UUID uuid;

    @BeforeEach
    public void init() {
        uuid = UUID.randomUUID();

        talent = Talent.builder().talentId(uuid).talentName("mrdevs").experience(10).employeeNumber("123455")
                .gender('L').talentDescription("testing description").email("mail@gmail.com").cellphone("081231231234")
                .biographyVideoUrl("https://youtube.com")
                .build();

    }

    @Test
    @DisplayName("GET /api/talent-management/talents")
    public void getTalents() throws Exception {
        List<TalentResponseDTO> talentResponseDTOs = new ArrayList<TalentResponseDTO>();
        talentResponseDTOs.add(new TalentResponseDTO(talent, null));
        talentResponseDTOs.add(new TalentResponseDTO(Talent.builder().talentId(UUID.randomUUID()).talentName("mrdevs2")
                .experience(10).employeeNumber("123455")
                .gender('L').talentDescription("testing description").email("mail@gmail.com").cellphone("081231231234")
                .biographyVideoUrl("https://youtube.com")
                .build(), null));
        GlobalListDTO<List<TalentResponseDTO>> responseBody = new GlobalListDTO<List<TalentResponseDTO>>();
        responseBody.setData(talentResponseDTOs);
        responseBody.setTotal(talentResponseDTOs.size());
        responseBody.setStatus(HttpStatus.OK.value());
        responseBody.setMessage(HttpStatus.OK.getReasonPhrase());

        ResponseEntity<GlobalListDTO<List<TalentResponseDTO>>> response = ResponseEntity.status(HttpStatus.OK)
                .body(responseBody);

        when(talentService.getTalents(PageRequest.of(0, 10), new TalentFilterRequestDTO())).thenReturn(response);

        mvc.perform(get("/talent-management/talents"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.status").isNotEmpty())
                .andExpect(MockMvcResultMatchers.jsonPath("$.status").value(HttpStatus.OK.value()))
                .andExpect(MockMvcResultMatchers.jsonPath("$.error").isEmpty())
                .andExpect(MockMvcResultMatchers.jsonPath("$.message").isNotEmpty())
                .andExpect(MockMvcResultMatchers.jsonPath("$.message").value(HttpStatus.OK.getReasonPhrase()))
                .andExpect(MockMvcResultMatchers.jsonPath("$.total").value(2))
                .andExpect(MockMvcResultMatchers.jsonPath("$.data").isNotEmpty())
                .andExpect(MockMvcResultMatchers.jsonPath("$.data").isArray())
                .andExpect(MockMvcResultMatchers.jsonPath("$.data[0].talentName").value("mrdevs"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.data[1].talentName").value("mrdevs2"));

    }

    @Test
    @DisplayName("GET /api/talent-management/talents/{talentId}")
    public void getTalentById() throws Exception {
        GlobalDTO<TalentDetailResponseDTO> responseBody = GlobalDTO.<TalentDetailResponseDTO>builder()
                .data(new TalentDetailResponseDTO(talent, null, null, 0)).status(HttpStatus.OK.value()).build();
        ResponseEntity<GlobalDTO<TalentDetailResponseDTO>> response = ResponseEntity.status(HttpStatus.OK)
                .body(responseBody);

        Mockito.when(talentService.getTalentById(uuid)).thenReturn(response);

        mvc.perform(get("/talent-management/talents/{talentId}", uuid))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.data.talentId").value(String.valueOf(uuid)))
                .andExpect(MockMvcResultMatchers.jsonPath("$.data.talentName").value("mrdevs"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.data.nip").value("123455"));

    }

}
