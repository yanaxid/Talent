package com.mrdevs.talent_center_be.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Optional;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.mrdevs.talent_center_be.dto.response.GlobalDTO;
import com.mrdevs.talent_center_be.dto.response.TalentDetailResponseDTO;
import com.mrdevs.talent_center_be.model.Talent;
import com.mrdevs.talent_center_be.repository.EmployeeStatusRepository;
import com.mrdevs.talent_center_be.repository.PositionRepository;
import com.mrdevs.talent_center_be.repository.SkillsetRepository;
import com.mrdevs.talent_center_be.repository.TalentLevelRepository;
import com.mrdevs.talent_center_be.repository.TalentMetadataRepository;
import com.mrdevs.talent_center_be.repository.TalentPositionRepository;
import com.mrdevs.talent_center_be.repository.TalentRepository;
import com.mrdevs.talent_center_be.repository.TalentRequestRepository;
import com.mrdevs.talent_center_be.repository.TalentSkillsetRepository;
import com.mrdevs.talent_center_be.repository.TalentStatusRepository;

import jakarta.validation.Validator;
import lib.i18n.utility.MessageUtil;

@ExtendWith(MockitoExtension.class)
public class TalentServiceTests {
    @Mock
    private MessageUtil messageUtil;
    @Mock
    private Validator validator;
    @Mock
    private MinioService minioService;
    @Mock
    private TalentRepository talentRepository;
    @Mock
    private TalentRequestRepository talentRequestRepository;
    @Mock
    private TalentStatusRepository talentStatusRepository;
    @Mock
    private EmployeeStatusRepository employeeStatusRepository;
    @Mock
    private TalentLevelRepository talentLevelRepository;
    @Mock
    private TalentPositionRepository talentPositionRepository;
    @Mock
    private PositionRepository positionRepository;
    @Mock
    private SkillsetRepository skillsetRepository;
    @Mock
    private TalentSkillsetRepository talentSkillsetRepository;
    @Mock
    private TalentMetadataRepository talentMetadataRepository;

    @InjectMocks
    private TalentService talentService;

    @BeforeEach
    public void setupBeforeEach() {
        System.out.println("Before Each Test");
    }

    @Test
    public void getTalentById() {
        UUID uuid = UUID.randomUUID();
        Talent talent = Talent.builder().talentId(uuid).talentName("mrdevs").experience(10).employeeNumber("123455")
                .gender('L').talentDescription("testing description").email("mail@gmail.com").cellphone("081231231234")
                .biographyVideoUrl("https://youtube.com")
                .build();
        when(talentRepository.findById(uuid)).thenReturn(Optional.of(talent));

        ResponseEntity<GlobalDTO<TalentDetailResponseDTO>> response = talentService.getTalentById(uuid);
        GlobalDTO<TalentDetailResponseDTO> responseBody = response.getBody();

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(null, responseBody.getError());
        assertEquals(HttpStatus.OK.value(), responseBody.getStatus());

        // body
        assertEquals("mrdevs", responseBody.getData().getTalentName());
        assertEquals(10, responseBody.getData().getTalentExperience());
        assertEquals("123455", responseBody.getData().getNip());
        assertEquals('L', responseBody.getData().getSex());
        assertEquals("testing description", responseBody.getData().getTalentDescription());
        assertEquals("mail@gmail.com", responseBody.getData().getEmail());
        assertEquals("081231231234", responseBody.getData().getCellphone());
        assertEquals("https://youtube.com", responseBody.getData().getVideoUrl());
    }

}
