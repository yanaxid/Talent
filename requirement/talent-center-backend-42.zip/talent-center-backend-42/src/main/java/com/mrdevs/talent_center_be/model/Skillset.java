package com.mrdevs.talent_center_be.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

import java.time.OffsetDateTime;
import java.util.Set;
import java.util.UUID;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.UuidGenerator;

@Entity
@Getter
@Setter
@Table(name = "skillset")
public class Skillset {

    @Id
    @Column(nullable = false, updatable = false)
    @GeneratedValue
    @UuidGenerator
    private UUID skillsetId;

    @Column(length = 50)
    private String skillsetName;

    @Column
    private Boolean isActive;

    @Column
    private String createdBy;

    @Column
    private OffsetDateTime createdTime;

    @Column
    private String lastModifiedBy;

    @Column
    private OffsetDateTime lastModifiedTime;

    @OneToMany(mappedBy = "skillset")
    private Set<MostFrequentSkillset> skillsetMostFrequentSkillsets;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "skillset_type_id")
    private SkillsetType skillsetType;

    @OneToMany(mappedBy = "skillset")
    private Set<TalentSkillset> skillsetTalentSkillsets;

}
