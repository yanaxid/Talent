package com.mrdevs.talent_center_be.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.time.OffsetDateTime;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "talent_approval_list_view")
public class TalentApprovalListView {

        @Id
        @Column(nullable = false, updatable = false)

        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private Integer talentRequestId;

        @Column
        private String agencyName;

        @Column
        private OffsetDateTime requestDate;

        @Column
        private String talentName;

        @Column
        private String talentRequestStatusName;

}
