package com.mrdevs.talent_center_be.dto.request;

import java.util.List;
import java.util.UUID;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateTalentRequestDTO {
    private UUID talentId;
    private String talentPhotoUrl;
    @NotNull(message = "talentName must not be null")
    @NotBlank(message = "talentName must not be blank")
    private String talentName;
    private UUID talentStatusId;
    private UUID employeeStatusId;
    private Boolean talentAvailability;
    @NotNull(message = "talentExperience must not be null")
    private Integer talentExperience;
    @NotNull(message = "talentLevelId must not be null")
    private UUID talentLevelId;
    private String nip;
    private Character sex;
    private String dob;
    private String talentDescription;
    private String cv;
    private Integer projectCompleted;
    private String email;
    private String cellphone;
    private String videoUrl;
    private List<PositionCreateTalentRequestDTO> position;
    private List<SkillsetCreateTalentRequestDTO> skillset;

}
