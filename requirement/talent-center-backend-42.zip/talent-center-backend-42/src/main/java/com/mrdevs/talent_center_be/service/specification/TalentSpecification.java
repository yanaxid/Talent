package com.mrdevs.talent_center_be.service.specification;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.domain.Specification;

import com.mrdevs.talent_center_be.dto.request.TalentApprovalFilterRequestDTO;
import com.mrdevs.talent_center_be.dto.request.TalentFilterRequestDTO;
import com.mrdevs.talent_center_be.model.Talent;
import com.mrdevs.talent_center_be.model.TalentRequest;

import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.From;
import jakarta.persistence.criteria.Predicate;

public class TalentSpecification {

        public static void applyTalentFilter(List<Predicate> predicates, From<?, Talent> root,
                        CriteriaBuilder criteriaBuilder, TalentFilterRequestDTO talentFilterRequestDTO) {

                if (talentFilterRequestDTO.getKeyword() != null) {
                        String keyword = "%" + talentFilterRequestDTO.getKeyword().toLowerCase() + "%";
                        Predicate talentNamePredicate = criteriaBuilder.like(
                                        criteriaBuilder.lower(root.get("talentName")),
                                        keyword);
                        Predicate employeeNumberPredicate = criteriaBuilder.like(
                                        criteriaBuilder.lower(root.get("employeeNumber")),
                                        keyword);
                        Predicate talentDescriptionPredicate = criteriaBuilder.like(
                                        criteriaBuilder.lower(root.get("talentDescription")),
                                        keyword);
                        Predicate emailPredicate = criteriaBuilder.like(
                                        criteriaBuilder.lower(root.get("email")),
                                        keyword);
                        Predicate keywordPredicate = criteriaBuilder.or(talentNamePredicate, employeeNumberPredicate,
                                        talentDescriptionPredicate, emailPredicate);
                        predicates.add(keywordPredicate);
                }

                if (talentFilterRequestDTO.getTalentName() != null) {
                        String talentNameValue = "%" + talentFilterRequestDTO.getTalentName().toLowerCase() + "%";
                        Predicate talentNamePredicate = criteriaBuilder.like(
                                        criteriaBuilder.lower(root.get("talentName")),
                                        talentNameValue);
                        predicates.add(talentNamePredicate);
                }
                if (talentFilterRequestDTO.getEmail() != null) {
                        String emailValue = "%" + talentFilterRequestDTO.getEmail().toLowerCase() + "%";
                        Predicate emailPredicate = criteriaBuilder.like(criteriaBuilder.lower(root.get("email")),
                                        emailValue);
                        predicates.add(emailPredicate);
                }
                if (talentFilterRequestDTO.getCellphone() != null) {
                        String cellphoneValue = "%" + talentFilterRequestDTO.getCellphone().toLowerCase() + "%";
                        Predicate cellphonePredicate = criteriaBuilder.like(
                                        criteriaBuilder.lower(root.get("cellphone")),
                                        cellphoneValue);
                        predicates.add(cellphonePredicate);
                }
                if (talentFilterRequestDTO.getTalentLevelId() != null) {
                        String talentLevelIdValue = "%" + talentFilterRequestDTO.getTalentLevelId() + "%";
                        Predicate talentLevelIdPredicate = criteriaBuilder.like(
                                        criteriaBuilder.toString(root.get("talentLevel").get("talentLevelId")),
                                        talentLevelIdValue);
                        predicates.add(talentLevelIdPredicate);
                }
                if (talentFilterRequestDTO.getTalentStatusId() != null) {
                        String talentStatusIdValue = "%" + talentFilterRequestDTO.getTalentStatusId() + "%";
                        Predicate talentStatusIdPredicate = criteriaBuilder.like(
                                        criteriaBuilder.toString(root.get("talentStatus").get("talentStatusId")),
                                        talentStatusIdValue);
                        predicates.add(talentStatusIdPredicate);
                }
                if (talentFilterRequestDTO.getEmployeeStatusId() != null) {
                        String employeeStatusIdValue = "%" + talentFilterRequestDTO.getEmployeeStatusId() + "%";
                        Predicate employeeStatusIdPredicate = criteriaBuilder.like(
                                        criteriaBuilder.toString(root.get("employeeStatus").get("employeeStatusId")),
                                        employeeStatusIdValue);
                        predicates.add(employeeStatusIdPredicate);
                }

                if (talentFilterRequestDTO.getExperienceRange() != null) {
                        if (talentFilterRequestDTO.getExperienceRange().split(",").length == 1) {
                                predicates.add(criteriaBuilder.greaterThanOrEqualTo(root.get("experience"),
                                                talentFilterRequestDTO.getExperienceRange().split(",")[0]));
                        } else if (talentFilterRequestDTO.getExperienceRange().split(",").length == 2) {
                                predicates.add(criteriaBuilder.between(root.get("experience"),
                                                talentFilterRequestDTO.getExperienceRange().split(",")[0],
                                                talentFilterRequestDTO.getExperienceRange().split(",")[1]));
                        }

                }

        }

        public static Specification<Talent> talentFilterAll(TalentFilterRequestDTO talentFilterRequestDTO) {
                return (root, query, criteriaBuilder) -> {
                        List<Predicate> predicates = new ArrayList<>();

                        applyTalentFilter(predicates, root, criteriaBuilder, talentFilterRequestDTO);

                        return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
                };
        }

        public static Specification<TalentRequest> talentApprovalFilterAll(
                        TalentApprovalFilterRequestDTO talentApprovalFilterRequestDTO) {
                return (root, query, criteriaBuilder) -> {
                        List<Predicate> predicates = new ArrayList<>();

                        if (talentApprovalFilterRequestDTO.getKeyword() != null) {
                                Predicate keywordPredicate;
                                String keyword = "%" + talentApprovalFilterRequestDTO.getKeyword().toLowerCase()
                                                + "%";
                                Predicate agencyNamePredicate = criteriaBuilder.like(
                                                criteriaBuilder.lower(root.get("talentWishlist").get("client")
                                                                .get("agencyName")),
                                                keyword);
                                Predicate talentNamePredicate = criteriaBuilder.like(
                                                criteriaBuilder.lower(root.get("talentWishlist").get("talent")
                                                                .get("talentName")),
                                                keyword);

                                if (talentApprovalFilterRequestDTO.getSearchBy() != null) {
                                        if (talentApprovalFilterRequestDTO.getSearchBy().equalsIgnoreCase("talent")) {
                                                keywordPredicate = talentNamePredicate;
                                        } else {
                                                keywordPredicate = agencyNamePredicate;
                                        }
                                } else {
                                        keywordPredicate = criteriaBuilder.or(agencyNamePredicate,
                                                        talentNamePredicate);
                                }
                                predicates.add(keywordPredicate);
                        }

                        if (talentApprovalFilterRequestDTO.getRequestDate() != null) {
                                String requestDate = "%" + talentApprovalFilterRequestDTO.getRequestDate().toLowerCase()
                                                + "%";
                                Predicate requestDatePredicate = criteriaBuilder.like(
                                                criteriaBuilder.function("TO_CHAR", String.class,
                                                                root.get("requestDate"),
                                                                criteriaBuilder.literal("YYYY-MM-DD")),
                                                requestDate);
                                predicates.add(requestDatePredicate);
                        }

                        if (talentApprovalFilterRequestDTO.getTalentRequestStatusName() != null) {
                                String talentRequestStatusIdValue = "%"
                                                + talentApprovalFilterRequestDTO.getTalentRequestStatusName() + "%";
                                Predicate talentRequestStatusIdPredicate = criteriaBuilder.like(
                                                criteriaBuilder.lower(root.get("talentRequestStatus")
                                                                .get("talentRequestStatusName")),
                                                talentRequestStatusIdValue);
                                predicates.add(talentRequestStatusIdPredicate);

                        }

                        return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
                };
        }
}
