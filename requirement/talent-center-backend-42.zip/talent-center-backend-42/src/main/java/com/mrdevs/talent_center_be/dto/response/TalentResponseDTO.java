package com.mrdevs.talent_center_be.dto.response;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import com.mrdevs.talent_center_be.model.Talent;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TalentResponseDTO {
        private UUID talentId;
        private String talentPhotoUrl;
        private String talentName;
        private String talentStatus;
        private String employeeStatus;
        private Boolean talentAvailability;
        private Integer talentExperience;
        private String talentLevel;
        private List<PositionResponseDTO> position;
        private List<SkillsetResponseDTO> skillset;

        public TalentResponseDTO(Talent talent, String talentPhotoUrl) {
                this.talentId = talent.getTalentId();
                this.talentPhotoUrl = talentPhotoUrl;
                this.talentName = talent.getTalentName();
                this.talentStatus = talent.getTalentStatus() != null ? talent.getTalentStatus().getTalentStatusName()
                                : null;
                this.employeeStatus = talent.getEmployeeStatus() != null
                                ? talent.getEmployeeStatus().getEmployeeStatusName()
                                : null;
                this.talentAvailability = talent.getTalentAvailability();
                this.talentExperience = talent.getExperience();
                this.talentLevel = talent.getTalentLevel() != null ? talent.getTalentLevel().getTalentLevelName()
                                : null;
                this.position = talent.getTalentTalentPositions() != null ? talent.getTalentTalentPositions().stream()
                                .map((item) -> new PositionResponseDTO(item.getPosition())).collect(Collectors.toList())
                                : null;
                this.skillset = talent.getTalentTalentSkillsets() != null ? talent.getTalentTalentSkillsets().stream()
                                .map((item) -> new SkillsetResponseDTO(item.getSkillset())).collect(Collectors.toList())
                                : null;

        }

}
