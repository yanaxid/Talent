package com.mrdevs.talent_center_be;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

@SpringBootApplication(scanBasePackages = { "com.mrdevs.talent_center_be", "lib.i18n" })
@EnableJpaAuditing
public class TalentCenterBeApplication {

	public static void main(String[] args) {
		SpringApplication.run(TalentCenterBeApplication.class, args);
	}

}
