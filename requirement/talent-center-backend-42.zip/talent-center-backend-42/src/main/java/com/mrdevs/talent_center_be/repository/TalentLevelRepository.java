package com.mrdevs.talent_center_be.repository;

import com.mrdevs.talent_center_be.model.TalentLevel;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

@Repository
public interface TalentLevelRepository extends JpaRepository<TalentLevel, UUID> {
}
