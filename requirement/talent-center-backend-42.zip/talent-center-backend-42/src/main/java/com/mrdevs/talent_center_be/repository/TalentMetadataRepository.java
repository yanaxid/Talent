package com.mrdevs.talent_center_be.repository;

import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.mrdevs.talent_center_be.model.TalentMetadata;
import com.mrdevs.talent_center_be.model.TalentMetadataId;

import org.springframework.stereotype.Repository;

@Repository
public interface TalentMetadataRepository extends JpaRepository<TalentMetadata, TalentMetadataId> {

    @Query("SELECT f FROM TalentMetadata f WHERE f.talent.talentId = :talentId")
    Optional<TalentMetadata> findByTalentId(@Param("talentId") UUID talentId);
}
