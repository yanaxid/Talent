package com.mrdevs.talent_center_be.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

import java.time.OffsetDateTime;
import java.util.Set;
import java.util.UUID;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.UuidGenerator;

@Entity
@Getter
@Setter
@Table(name = "client_position")
public class ClientPosition {

    @Id
    @Column(nullable = false, updatable = false)
    @GeneratedValue
    @UuidGenerator
    private UUID clientPositionId;

    @Column(length = 100)
    private String clientPositionName;

    @Column
    private Boolean isActive;

    @Column
    private String createdBy;

    @Column
    private OffsetDateTime createdTime;

    @Column
    private String lastModifiedBy;

    @Column
    private OffsetDateTime lastModifiedTime;

    @OneToMany(mappedBy = "clientPosition")
    private Set<Client> clientPositionClients;

}
