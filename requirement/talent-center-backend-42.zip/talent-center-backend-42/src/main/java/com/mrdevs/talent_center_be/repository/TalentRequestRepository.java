package com.mrdevs.talent_center_be.repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.mrdevs.talent_center_be.model.TalentRequest;
import com.mrdevs.talent_center_be.model.TalentWishlist;

@Repository
public interface TalentRequestRepository
        extends JpaRepository<TalentRequest, UUID>, JpaSpecificationExecutor<TalentRequest> {

    long count(Specification<TalentRequest> spec);

    List<TalentRequest> findByTalentWishlist(TalentWishlist talentWishlist);

    @Query("SELECT COUNT(f) FROM TalentRequest f WHERE f.talentWishlist.talentWishlistId= :talentWishlistId")
    Integer countByTalentWhislistId(@Param("talentWishlistId") UUID talentWishlistId);
}
