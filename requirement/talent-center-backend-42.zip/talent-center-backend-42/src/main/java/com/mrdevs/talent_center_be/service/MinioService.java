package com.mrdevs.talent_center_be.service;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import io.minio.GetObjectArgs;
import io.minio.GetPresignedObjectUrlArgs;
import io.minio.MinioClient;
import io.minio.PutObjectArgs;
import io.minio.RemoveObjectArgs;
import io.minio.errors.MinioException;
import io.minio.http.Method;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class MinioService {
    public static final Long DEFAULT_EXPIRY = TimeUnit.HOURS.toSeconds(1);

    private final MinioClient minioClient;

    @Value("${application.minio.bucket-name}")
    private String bucketName;

    private String sanitizeForFilename(String input) {
        return input.replaceAll("[^a-zA-Z0-9]", "_");
    }

    public String getFileExtension(String filename) {
        int dotIndex = filename.lastIndexOf('.');
        return (dotIndex == -1) ? "" : filename.substring(dotIndex);
    }

    private String getFileUrl(String filename, long expiry) {
        try {
            return minioClient.getPresignedObjectUrl(
                    GetPresignedObjectUrlArgs.builder()
                            .method(Method.GET)
                            .bucket(bucketName)
                            .object(filename)
                            .expiry(Math.toIntExact(expiry), TimeUnit.SECONDS)
                            .build());
        } catch (Exception e) {
            log.error(filename, e);
            return null;
            // throw new RuntimeException("Error generating pre-signed URL", e);
        }
    }

    public boolean fileExists(String filename) {
        try {
            minioClient.getObject(
                    GetObjectArgs.builder()
                            .bucket(bucketName)
                            .object(filename)
                            .build());
            return true;
        } catch (MinioException e) {
            log.error(filename, e);
            return false;
        } catch (Exception e) {
            if (filename == null) {
                return false;
            }
            log.error(filename, e);
            throw new RuntimeException("Error checking if file exists in MinIO", e);
        }
    }

    public void deleteFile(String filename) {
        try {
            minioClient.removeObject(
                    RemoveObjectArgs.builder()
                            .bucket(bucketName)
                            .object(filename)
                            .build());
        } catch (Exception e) {
            log.error(filename, e);
            throw new RuntimeException("Error deleting file from MinIO", e);
        }
    }

    public String getPublicLink(String filename) {
        return filename != null ? this.getFileUrl(filename, DEFAULT_EXPIRY) : null;
    }

    public String generatedFilename(String prefix, String talentName, Integer talentExperience, String talentLevelName,
            MultipartFile file) {
        String timestamp = String.valueOf(System.currentTimeMillis());
        String fileExtension = getFileExtension(file.getOriginalFilename());
        return String.format(
                "%s_%s_%s_%s_%s%s",
                sanitizeForFilename(prefix),
                sanitizeForFilename(talentName),
                sanitizeForFilename(String.valueOf(talentExperience)),
                sanitizeForFilename(talentLevelName),
                timestamp,
                fileExtension);
    }

    public void uploadFile(String filename, MultipartFile file) throws IOException {

        try {
            minioClient.putObject(
                    PutObjectArgs.builder()
                            .bucket(bucketName)
                            .object(filename)
                            .stream(file.getInputStream(), file.getSize(), -1)
                            .contentType(file.getContentType())
                            .build());
        } catch (Exception e) {
            log.error(filename, e);
            throw new IOException("Error uploading file to MinIO", e);
        }
    }

    public void updateFile(String filename, String newFilename, MultipartFile file) throws IOException {
        if (fileExists(filename)) {
            deleteFile(filename);
        }
        uploadFile(newFilename, file);
    }

}
