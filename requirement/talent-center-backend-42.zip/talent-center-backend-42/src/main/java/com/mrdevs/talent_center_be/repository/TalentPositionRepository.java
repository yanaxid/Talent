package com.mrdevs.talent_center_be.repository;

import com.mrdevs.talent_center_be.model.TalentPosition;

import jakarta.transaction.Transactional;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface TalentPositionRepository extends JpaRepository<TalentPosition, Integer> {
    @Query("SELECT f FROM TalentPosition f WHERE f.talent.talentId = :talentId")
    List<TalentPosition> getTalentPositions(@Param("talentId") UUID talentId);

    @Modifying
    @Transactional
    @Query("DELETE  FROM TalentPosition tp WHERE tp.talent.talentId = :talentId")
    void deleteByTalentId(@Param("talentId") UUID talentId);
}
