package com.mrdevs.talent_center_be.repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.mrdevs.talent_center_be.model.TalentSkillset;
import com.mrdevs.talent_center_be.model.TalentSkillsetId;

import jakarta.transaction.Transactional;

import org.springframework.stereotype.Repository;

@Repository
public interface TalentSkillsetRepository extends JpaRepository<TalentSkillset, TalentSkillsetId> {

    @Query("SELECT f FROM TalentSkillset f WHERE f.talent.talentId = :talentId")
    List<TalentSkillset> getTalentSkillsets(@Param("talentId") UUID talentId);

    @Query("SELECT f FROM TalentSkillset f WHERE f.talent.talentId = :talentId AND f.skillset.skillsetId=:skillsetId")
    Optional<TalentSkillset> findBySkillsetIdTalent(@Param("talentId") UUID talentId,
            @Param("skillsetId") UUID skillsetId);

    @Modifying
    @Transactional
    @Query("DELETE FROM TalentSkillset tp WHERE tp.talent.talentId = :talentId")
    void deleteByTalentId(@Param("talentId") UUID talentId);
}
