package com.mrdevs.talent_center_be.dto.response;

import java.util.UUID;

import com.mrdevs.talent_center_be.model.Position;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PositionResponseDTO {
    private UUID positionId;
    private String positionName;

    public PositionResponseDTO(Position position) {
        this.positionId = position.getPositionId();
        this.positionName = position.getPositionName();
    }

}
