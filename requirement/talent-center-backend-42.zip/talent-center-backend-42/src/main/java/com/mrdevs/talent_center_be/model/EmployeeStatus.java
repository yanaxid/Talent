package com.mrdevs.talent_center_be.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

import java.time.OffsetDateTime;
import java.util.Set;
import java.util.UUID;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.UuidGenerator;

@Entity
@Getter
@Setter
@Table(name = "employee_status")
public class EmployeeStatus {

    @Id
    @Column(name = "employee_status_id", nullable = false, updatable = false)
    @GeneratedValue
    @UuidGenerator
    private UUID employeeStatusId;

    @Column(name = "employee_status_name")
    private String employeeStatusName;

    @Column(name = "created_by")
    private String createdBy;

    @Column(name = "created_time")
    private OffsetDateTime createdTime;

    @Column(name = "last_modified_by")
    private String lastModifiedBy;

    @Column(name = "last_modified_time")
    private OffsetDateTime lastModifiedTime;

    @OneToMany(mappedBy = "employeeStatus")
    private Set<Talent> employeeStatusTalents;

}
