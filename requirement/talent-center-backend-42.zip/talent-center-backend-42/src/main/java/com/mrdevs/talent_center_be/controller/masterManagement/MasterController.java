package com.mrdevs.talent_center_be.controller.masterManagement;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mrdevs.talent_center_be.dto.response.EmployeeStatusResponseDTO;
import com.mrdevs.talent_center_be.dto.response.GlobalDTO;
import com.mrdevs.talent_center_be.dto.response.PositionResponseDTO;
import com.mrdevs.talent_center_be.dto.response.SkillsetResponseDTO;
import com.mrdevs.talent_center_be.dto.response.TalentLevelResponseDTO;
import com.mrdevs.talent_center_be.dto.response.TalentStatusResponseDTO;
import com.mrdevs.talent_center_be.service.MasterService;

import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

@Tag(name = "Master", description = "Master Management APIs")
@RestController
@RequestMapping("/master-management")
@RequiredArgsConstructor
public class MasterController {

    private final MasterService masterService;

    @GetMapping("/employee-status-option-lists")
    public ResponseEntity<GlobalDTO<List<EmployeeStatusResponseDTO>>> getEmployeeStatuses() {
        return masterService.getEmployeeStatuses();
    }

    @GetMapping("/talent-status-option-lists")
    public ResponseEntity<GlobalDTO<List<TalentStatusResponseDTO>>> getTalentStatuses() {
        return masterService.getTalentStatuses();
    }

    @GetMapping("/talent-level-option-lists")
    public ResponseEntity<GlobalDTO<List<TalentLevelResponseDTO>>> getTalentLevels() {
        return masterService.getTalentLevels();
    }

    @GetMapping("/position-option-lists")
    public ResponseEntity<GlobalDTO<List<PositionResponseDTO>>> getPositions() {
        return masterService.getPositions();
    }

    @GetMapping("/skillset-option-lists")
    public ResponseEntity<GlobalDTO<List<SkillsetResponseDTO>>> getSkillsets() {
        return masterService.getSkillsets();
    }

}
