package com.mrdevs.talent_center_be.dto.request;

import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TalentApprovalFilterRequestDTO {
    private UUID talentRequestId;
    private String agencyName;
    private String talentName;
    private String requestDate;
    private String talentRequestStatusName;
    private String searchBy;
    private String keyword;

}
