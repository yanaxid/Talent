package com.mrdevs.talent_center_be.repository;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mrdevs.talent_center_be.model.TalentRequestStatus;

@Repository
public interface TalentRequestStatusRepository extends JpaRepository<TalentRequestStatus, UUID> {

}
