package com.mrdevs.talent_center_be.model;

import java.time.OffsetDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.MapsId;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "talent_metadata")
public class TalentMetadata {

        @EmbeddedId
        private TalentMetadataId id;

        @Column(name = "cv_counter")
        private Integer cvCounter;

        @Column(name = "profile_counter")
        private Integer profileCounter;

        @Column(name = "total_project_completed")
        private Integer totalProjectCompleted;

        @Column(name = "created_by", length = 50)
        private String createdBy;

        @Column(name = "created_time")
        private OffsetDateTime createdTime;

        @Column(name = "last_modified_by", length = 50)
        private String lastModifiedBy;

        @Column(name = "last_modified_time")
        private OffsetDateTime lastModifiedTime;

        @MapsId("talentId")
        @ManyToOne(fetch = FetchType.LAZY)
        @JoinColumn(name = "talent_id", nullable = false)
        private Talent talent;

        @PrePersist
        protected void onCreate() {
                this.createdTime = OffsetDateTime.now();
        }

        @PreUpdate
        protected void onUpdate() {
                this.lastModifiedTime = OffsetDateTime.now();
        }

}
