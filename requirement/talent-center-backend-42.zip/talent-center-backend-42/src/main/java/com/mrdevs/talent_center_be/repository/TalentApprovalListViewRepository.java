package com.mrdevs.talent_center_be.repository;

import com.mrdevs.talent_center_be.model.TalentApprovalListView;
import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

@Repository
public interface TalentApprovalListViewRepository extends JpaRepository<TalentApprovalListView, Integer> {
}
