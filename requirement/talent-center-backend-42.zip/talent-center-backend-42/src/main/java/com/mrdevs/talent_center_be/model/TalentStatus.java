package com.mrdevs.talent_center_be.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

import java.time.OffsetDateTime;
import java.util.Set;
import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.UuidGenerator;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "talent_status")
public class TalentStatus {

    @Id
    @Column(name = "talent_status_id", nullable = false, updatable = false)
    @GeneratedValue
    @UuidGenerator
    private UUID talentStatusId;

    @Column(name = "talent_status_name", length = 50)
    private String talentStatusName;

    @Column(name = "is_active")
    private Boolean isActive;

    @Column(name = "created_by", length = 50)
    private String createdBy;

    @Column(name = "created_time")
    private OffsetDateTime createdTime;

    @Column(name = "last_modified_by", length = 50)
    private String lastModifiedBy;

    @Column(name = "last_modified_time")
    private OffsetDateTime lastModifiedTime;

    @OneToMany(mappedBy = "talentStatus")
    private Set<Talent> talentStatusTalents;

}
