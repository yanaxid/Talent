package com.mrdevs.talent_center_be.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.time.OffsetDateTime;
import java.util.UUID;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.UuidGenerator;

@Entity
@Getter
@Setter
@Table(name = "talent_request_wishlist_view")
public class TalentRequestWishlistView {

    @Id
    @Column(nullable = false, updatable = false)
    @GeneratedValue
    @UuidGenerator
    private UUID requestId;

    @Column
    private UUID clientId;

    @Column
    private OffsetDateTime requestDate;

    @Column
    private String requestRejectReason;

    @Column
    private UUID requestStatusId;

    @Column
    private UUID talentId;

    @Column
    private UUID wishlistId;

}
