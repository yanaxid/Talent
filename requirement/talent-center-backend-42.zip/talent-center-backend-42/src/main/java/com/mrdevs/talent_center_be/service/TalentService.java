package com.mrdevs.talent_center_be.service;

import java.time.LocalDate;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.mrdevs.talent_center_be.dto.request.ApprovalRequestDTO;
import com.mrdevs.talent_center_be.dto.request.CreateTalentRequestDTO;
import com.mrdevs.talent_center_be.dto.request.PositionCreateTalentRequestDTO;
import com.mrdevs.talent_center_be.dto.request.SkillsetCreateTalentRequestDTO;
import com.mrdevs.talent_center_be.dto.request.TalentApprovalFilterRequestDTO;
import com.mrdevs.talent_center_be.dto.request.TalentFilterRequestDTO;
import com.mrdevs.talent_center_be.dto.request.UpdateTalentRequestDTO;
import com.mrdevs.talent_center_be.dto.response.GlobalDTO;
import com.mrdevs.talent_center_be.dto.response.GlobalListDTO;
import com.mrdevs.talent_center_be.dto.response.TalentApprovalResponseDTO;
import com.mrdevs.talent_center_be.dto.response.TalentDetailResponseDTO;
import com.mrdevs.talent_center_be.dto.response.TalentResponseDTO;
import com.mrdevs.talent_center_be.exception.ErrorWithStatusException;
import com.mrdevs.talent_center_be.model.EmployeeStatus;
import com.mrdevs.talent_center_be.model.Position;
import com.mrdevs.talent_center_be.model.Skillset;
import com.mrdevs.talent_center_be.model.Talent;
import com.mrdevs.talent_center_be.model.TalentLevel;
import com.mrdevs.talent_center_be.model.TalentMetadata;
import com.mrdevs.talent_center_be.model.TalentMetadataId;
import com.mrdevs.talent_center_be.model.TalentPosition;
import com.mrdevs.talent_center_be.model.TalentRequest;
import com.mrdevs.talent_center_be.model.TalentSkillset;
import com.mrdevs.talent_center_be.model.TalentSkillsetId;
import com.mrdevs.talent_center_be.model.TalentStatus;
import com.mrdevs.talent_center_be.model.TalentWishlist;
import com.mrdevs.talent_center_be.repository.EmployeeStatusRepository;
import com.mrdevs.talent_center_be.repository.PositionRepository;
import com.mrdevs.talent_center_be.repository.SkillsetRepository;
import com.mrdevs.talent_center_be.repository.TalentLevelRepository;
import com.mrdevs.talent_center_be.repository.TalentMetadataRepository;
import com.mrdevs.talent_center_be.repository.TalentPositionRepository;
import com.mrdevs.talent_center_be.repository.TalentRepository;
import com.mrdevs.talent_center_be.repository.TalentRequestRepository;
import com.mrdevs.talent_center_be.repository.TalentSkillsetRepository;
import com.mrdevs.talent_center_be.repository.TalentStatusRepository;
import com.mrdevs.talent_center_be.service.specification.TalentSpecification;

import jakarta.transaction.Transactional;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validator;
import lib.i18n.utility.MessageUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class TalentService {
    private final MessageUtil messageUtil;
    private final TalentRepository talentRepository;
    private final TalentRequestRepository talentRequestRepository;
    private final Validator validator;
    private final MinioService minioService;
    private final TalentStatusRepository talentStatusRepository;
    private final EmployeeStatusRepository employeeStatusRepository;
    private final TalentLevelRepository talentLevelRepository;
    private final TalentPositionRepository talentPositionRepository;
    private final PositionRepository positionRepository;
    private final SkillsetRepository skillsetRepository;
    private final TalentSkillsetRepository talentSkillsetRepository;
    private final TalentMetadataRepository talentMetadataRepository;

    @Transactional
    public ResponseEntity<GlobalListDTO<List<TalentResponseDTO>>> getTalents(Pageable page,
            TalentFilterRequestDTO requestFilter) {
        GlobalListDTO<List<TalentResponseDTO>> response = new GlobalListDTO<List<TalentResponseDTO>>();

        HttpStatus status = HttpStatus.OK;
        String message = "";

        log.info(messageUtil.get("log.success.request.received", "get talents", requestFilter.toString(), "anonymous"));

        Specification<Talent> spec = TalentSpecification.talentFilterAll(requestFilter);
        long totalData = talentRepository.count(spec);
        try {
            Page<Talent> talentFiltered = talentRepository.findAll(spec, page);
            List<TalentResponseDTO> responseData = talentFiltered.stream().map(
                    (item) -> new TalentResponseDTO(item,
                            minioService.getPublicLink(item.getTalentPhotoFilename())))
                    .collect(Collectors.toList());

            if (responseData.isEmpty()) {
                throw new ErrorWithStatusException(messageUtil.get("application.error.talent.not-found"),
                        HttpStatus.OK);
            }

            message = messageUtil.get("application.success.talent.found");
            response.setData(responseData);
            log.info(message);
        } catch (ErrorWithStatusException err) {
            status = err.getStatus();
            message = err.getMessage();
            response.setData(new ArrayList<TalentResponseDTO>());
            response.setError(err.getStatus().getReasonPhrase());
            log.error(err.getMessage());
        } catch (Exception err) {
            status = HttpStatus.INTERNAL_SERVER_ERROR;
            message = err.getMessage();
            response.setData(new ArrayList<TalentResponseDTO>());
            response.setError(status.getReasonPhrase());
            log.error(err.getMessage());
        }

        response.setStatus(status.value());
        response.setMessage(message);
        response.setPage(page);
        response.setTotal(totalData);
        return ResponseEntity.status(status).body(response);

    }

    @Transactional
    public ResponseEntity<GlobalDTO<TalentDetailResponseDTO>> getTalentById(UUID talentId) {

        GlobalDTO<TalentDetailResponseDTO> response = new GlobalDTO<TalentDetailResponseDTO>();

        HttpStatus status = HttpStatus.OK;
        String message = "";

        log.info(messageUtil.get("log.success.request.received", "get talent by id", talentId.toString(), "anonymous"));

        try {
            Optional<Talent> talent = talentRepository.findById(talentId);
            if (talent.isEmpty()) {
                throw new ErrorWithStatusException(
                        messageUtil.get("application.error.talent.not-found", talentId.toString()),
                        HttpStatus.NOT_FOUND);
            }

            Set<TalentWishlist> talentWhislists = talent.get().getTalentTalentWishlists();
            Integer totalRequested = 0;
            if (talentWhislists != null && !talentWhislists.isEmpty()) {
                for (TalentWishlist talentWishlist : talentWhislists) {
                    totalRequested += talentRequestRepository
                            .countByTalentWhislistId(talentWishlist.getTalentWishlistId());
                }
            }

            message = messageUtil.get("application.success.talent.found");

            response.setData(new TalentDetailResponseDTO(talent.get(),
                    minioService.getPublicLink(talent.get().getTalentPhotoFilename()),
                    minioService.getPublicLink(talent.get().getTalentCvFilename()),
                    totalRequested));
            log.info(message);

        } catch (ErrorWithStatusException err) {
            status = err.getStatus();
            message = err.getMessage();
            response.setError(err.getStatus().getReasonPhrase());
            log.error(err.getMessage());
        } catch (Exception err) {
            status = HttpStatus.INTERNAL_SERVER_ERROR;
            message = err.getMessage();
            response.setError(status.getReasonPhrase());
            log.error(err.getMessage());
        }

        response.setStatus(status.value());
        response.setMessage(message);
        return ResponseEntity.status(status).body(response);

    }

    @Transactional
    public ResponseEntity<GlobalListDTO<List<TalentApprovalResponseDTO>>> getTalentApprovals(Pageable page,
            TalentApprovalFilterRequestDTO requestFilter) {
        GlobalListDTO<List<TalentApprovalResponseDTO>> response = new GlobalListDTO<List<TalentApprovalResponseDTO>>();

        HttpStatus status = HttpStatus.OK;
        String message = "";

        log.info(messageUtil.get("log.success.request.received", "get talent approvals", requestFilter.toString(),
                "anonymous"));

        // to be implement spec
        Specification<TalentRequest> spec = TalentSpecification.talentApprovalFilterAll(requestFilter);
        long totalData = talentRequestRepository.count(spec);

        try {

            Page<TalentRequest> talentRequestFiltered = talentRequestRepository.findAll(spec, page);
            List<TalentApprovalResponseDTO> responseData = talentRequestFiltered.stream()
                    .map((item) -> new TalentApprovalResponseDTO(item.getTalentRequestId(),
                            item.getTalentWishlist().getClient().getAgencyName(),
                            item.getRequestDate() != null
                                    ? item.getRequestDate().format(DateTimeFormatter.ISO_LOCAL_DATE)
                                    : null,
                            item.getTalentWishlist().getTalent().getTalentName(),
                            item.getTalentRequestStatus().getTalentRequestStatusName(),
                            item.getTalentRequestStatus().getIsActive()))
                    .collect(Collectors.toList());

            if (responseData.isEmpty()) {
                throw new ErrorWithStatusException(messageUtil.get("application.error.talent-approval.not-found"),
                        HttpStatus.OK);
            }

            message = messageUtil.get("application.success.talent-approval.found");
            response.setData(responseData);
            log.info(message);

        } catch (ErrorWithStatusException err) {
            status = err.getStatus();
            message = err.getMessage();
            response.setData(new ArrayList<TalentApprovalResponseDTO>());
            response.setError(err.getStatus().getReasonPhrase());
            log.error(err.getMessage());
        } catch (Exception err) {
            status = HttpStatus.INTERNAL_SERVER_ERROR;
            message = err.getMessage();
            response.setData(new ArrayList<TalentApprovalResponseDTO>());
            response.setError(status.getReasonPhrase());
            log.error(err.getMessage());
        }

        response.setStatus(status.value());
        response.setMessage(message);
        response.setPage(page);
        response.setTotal(totalData);
        return ResponseEntity.status(status).body(response);

    }

    @Transactional
    public ResponseEntity<GlobalDTO<TalentApprovalResponseDTO>> updateTalentApprovalStatus(ApprovalRequestDTO request) {
        Set<ConstraintViolation<ApprovalRequestDTO>> constraintViolations = validator.validate(request);
        GlobalDTO<TalentApprovalResponseDTO> response = new GlobalDTO<TalentApprovalResponseDTO>();

        HttpStatus status = HttpStatus.OK;
        String message = "";

        log.info(messageUtil.get("log.success.request.received", "get talent approvals", request.toString(),
                "anonymous"));

        try {

            Optional<TalentRequest> talentRequest = talentRequestRepository
                    .findById(UUID.fromString(request.getTalentRequestId()));

            if (talentRequest.isEmpty()) {
                throw new ErrorWithStatusException(
                        messageUtil.get("application.error.talent-approval.not-found-id",
                                request.getTalentRequestId().toString()),
                        HttpStatus.NOT_FOUND);
            }

            if (!constraintViolations.isEmpty()) {
                ConstraintViolation<ApprovalRequestDTO> firstViolation = constraintViolations.iterator().next();
                throw new ErrorWithStatusException(firstViolation.getMessage(), HttpStatus.BAD_REQUEST);
            }

            if (!request.getAction().equalsIgnoreCase("approve")
                    && !request.getAction().equalsIgnoreCase("reject")) {
                throw new ErrorWithStatusException("only supports approve or reject action", HttpStatus.BAD_REQUEST);
            }

            if (talentRequest.get().getTalentRequestStatus().getIsActive() == false && (talentRequest.get()
                    .getTalentRequestStatus().getTalentRequestStatusName().equalsIgnoreCase("approved")
                    || talentRequest.get()
                            .getTalentRequestStatus().getTalentRequestStatusName().equalsIgnoreCase("rejected"))) {
                throw new ErrorWithStatusException("Status was updated before", HttpStatus.BAD_REQUEST);
            }

            String requestStatus = request.getAction().equalsIgnoreCase("approve") ? "Approved" : "Rejected";
            talentRequest.get().getTalentRequestStatus().setTalentRequestStatusName(requestStatus);
            talentRequest.get().getTalentRequestStatus().setIsActive(false);
            if (request.getRejectReason() != null) {
                talentRequest.get().setRequestRejectReason(request.getRejectReason());
            }
            talentRequestRepository.save(talentRequest.get());

            message = messageUtil.get("application.success.update.talent-approval",
                    request.getTalentRequestId().toString());
            response.setData(new TalentApprovalResponseDTO(talentRequest.get().getTalentRequestId(),
                    talentRequest.get().getTalentWishlist().getClient().getAgencyName(),
                    talentRequest.get().getRequestDate() != null
                            ? talentRequest.get().getRequestDate().format(DateTimeFormatter.ISO_LOCAL_DATE)
                            : null,
                    talentRequest.get().getTalentWishlist().getTalent().getTalentName(),
                    talentRequest.get().getTalentRequestStatus().getTalentRequestStatusName(),
                    talentRequest.get().getTalentRequestStatus().getIsActive()));
            log.info(message);

        } catch (ErrorWithStatusException err) {
            status = err.getStatus();
            message = err.getMessage();
            response.setError(err.getStatus().getReasonPhrase());
            log.error(err.getMessage());
            throw new ErrorWithStatusException(err.getMessage(), err.getStatus());
        } catch (Exception err) {
            status = HttpStatus.INTERNAL_SERVER_ERROR;
            message = err.getMessage();
            response.setError(status.getReasonPhrase());
            log.error(err.getMessage());
            throw new ErrorWithStatusException(err.getMessage(), status);
        }

        response.setStatus(status.value());
        response.setMessage(message);
        return ResponseEntity.status(status).body(response);

    }

    @Transactional
    public ResponseEntity<GlobalDTO<TalentDetailResponseDTO>> createTalent(CreateTalentRequestDTO request,
            MultipartFile talentPhotoFile,
            MultipartFile cvFile) {
        Set<ConstraintViolation<CreateTalentRequestDTO>> constraintViolations = validator.validate(request);
        GlobalDTO<TalentDetailResponseDTO> response = new GlobalDTO<TalentDetailResponseDTO>();

        HttpStatus status = HttpStatus.OK;
        String message = "";

        log.info(messageUtil.get("log.success.request.received", "create talent", request.toString(),
                "anonymous"));

        try {
            Talent talentTemp = new Talent();
            if (!constraintViolations.isEmpty()) {
                ConstraintViolation<CreateTalentRequestDTO> firstViolation = constraintViolations.iterator().next();
                throw new ErrorWithStatusException(firstViolation.getMessage(), HttpStatus.BAD_REQUEST);
            }

            if (request.getTalentStatusId() != null) {
                Optional<TalentStatus> talentStatus = talentStatusRepository.findById(request.getTalentStatusId());
                if (talentStatus.isEmpty()) {
                    throw new ErrorWithStatusException(
                            "talentStatusId: " + request.getTalentStatusId() + " is not found or invalid.",
                            HttpStatus.NOT_FOUND);
                }
                talentTemp.setTalentStatus(talentStatus.get());
            }
            if (request.getTalentLevelId() != null) {
                Optional<TalentLevel> talentLevel = talentLevelRepository.findById(request.getTalentLevelId());
                if (talentLevel.isEmpty()) {
                    throw new ErrorWithStatusException(
                            "talentLevelId: " + request.getTalentLevelId() + " is not found or invalid.",
                            HttpStatus.NOT_FOUND);
                }
                talentTemp.setTalentLevel(talentLevel.get());
            }
            if (request.getEmployeeStatusId() != null) {
                Optional<EmployeeStatus> employeeStatus = employeeStatusRepository
                        .findById(request.getEmployeeStatusId());
                if (employeeStatus.isEmpty()) {
                    throw new ErrorWithStatusException(
                            "employeeStatus: " + request.getEmployeeStatusId() + " is not found or invalid.",
                            HttpStatus.NOT_FOUND);
                }
                talentTemp.setEmployeeStatus(employeeStatus.get());
            }

            if (talentPhotoFile != null && !talentPhotoFile.isEmpty()) {
                String filename = minioService.generatedFilename("profile", request.getTalentName(),
                        request.getTalentExperience(),
                        talentTemp.getTalentLevel().getTalentLevelName(), talentPhotoFile);

                minioService.uploadFile(filename, talentPhotoFile);
                talentTemp.setTalentPhotoFilename(filename);
            }
            if (cvFile != null && !cvFile.isEmpty()) {
                String filename = minioService.generatedFilename("cv", request.getTalentName(),
                        request.getTalentExperience(),
                        talentTemp.getTalentLevel().getTalentLevelName(), cvFile);

                minioService.uploadFile(filename, cvFile);
                talentTemp.setTalentCvFilename(filename);
            }

            if (request.getDob() != null) {
                talentTemp.setBirthDate(LocalDate.parse(request.getDob(), DateTimeFormatter.ofPattern("yyyy-MM-dd"))
                        .atStartOfDay().atOffset(ZoneOffset.UTC));
            }

            talentTemp.setTalentName(request.getTalentName());
            talentTemp.setTalentAvailability(request.getTalentAvailability());
            talentTemp.setExperience(request.getTalentExperience());
            talentTemp.setEmployeeNumber(request.getNip());
            talentTemp.setGender(request.getSex());

            talentTemp.setTalentDescription(request.getTalentDescription());
            talentTemp.setTotalProjectCompleted(request.getProjectCompleted());
            talentTemp.setEmail(request.getEmail());
            talentTemp.setCellphone(request.getCellphone());
            talentTemp.setBiographyVideoUrl(request.getVideoUrl());
            talentTemp.setIsActive(true);
            talentTemp.setCreatedBy("mrdevsAPI");
            talentRepository.save(talentTemp);

            Optional<Talent> talent = talentRepository.findById(talentTemp.getTalentId());

            if (talent.isEmpty()) {
                throw new ErrorWithStatusException(
                        messageUtil.get("application.error.talent.not-found-id", talentTemp.getTalentId().toString()),
                        HttpStatus.NOT_FOUND);
            }

            TalentMetadata talentMetadata = TalentMetadata.builder()
                    .id(TalentMetadataId.builder().talentId(talent.get().getTalentId()).build())
                    .talent(talent.get())
                    .cvCounter(0)
                    .profileCounter(0)
                    .totalProjectCompleted(request.getProjectCompleted() != null ? request.getProjectCompleted() : 0)
                    .createdBy("mrdevsAPI").build();
            talentMetadataRepository.save(talentMetadata);

            if (request.getPosition() != null && request.getPosition().size() > 0) {
                for (PositionCreateTalentRequestDTO position : request.getPosition()) {
                    Optional<Position> positions = positionRepository.findById(position.getPositionId());
                    if (positions.isEmpty()) {
                        throw new ErrorWithStatusException(
                                "position: " + position.getPositionId() + " is not found or invalid.",
                                HttpStatus.NOT_FOUND);
                    } else {
                        TalentPosition talentPosition = TalentPosition.builder().talent(talent.get())
                                .position(positions.get()).createdBy("mrdevsAPI").build();
                        talentPositionRepository.save(talentPosition);
                    }
                }
            }
            if (request.getSkillset() != null && request.getSkillset().size() > 0) {
                for (SkillsetCreateTalentRequestDTO skillset : request.getSkillset()) {

                    Optional<Skillset> skillsets = skillsetRepository.findById(skillset.getSkillId());
                    if (skillsets.isEmpty()) {
                        throw new ErrorWithStatusException(
                                "skillset: " + skillset.getSkillId() + " is not found or invalid.",
                                HttpStatus.NOT_FOUND);
                    } else {
                        TalentSkillset talentSkillset = TalentSkillset.builder()
                                .id(TalentSkillsetId.builder().talentId(talent.get().getTalentId())
                                        .skillsetId(skillsets.get().getSkillsetId()).build())
                                .talent(talent.get())
                                .skillset(skillsets.get()).createdBy("mrdevsAPI").build();
                        talentSkillsetRepository.save(talentSkillset);
                    }
                }
            }

            Set<TalentWishlist> talentWhislists = talent.get().getTalentTalentWishlists();
            Integer totalRequested = 0;
            if (talentWhislists != null && !talentWhislists.isEmpty()) {
                for (TalentWishlist talentWishlist : talentWhislists) {
                    totalRequested += talentRequestRepository
                            .countByTalentWhislistId(talentWishlist.getTalentWishlistId());
                }
            }

            message = messageUtil.get("application.success.add.talent",
                    request.getTalentName());
            response.setData(
                    new TalentDetailResponseDTO(talent.get(),
                            minioService.getPublicLink(talent.get().getTalentPhotoFilename()),
                            minioService.getPublicLink(talent.get().getTalentCvFilename()), totalRequested));
            log.info(message);

        } catch (ErrorWithStatusException err) {
            status = err.getStatus();
            message = err.getMessage();
            response.setError(err.getStatus().getReasonPhrase());
            log.error(err.getMessage());
            throw new ErrorWithStatusException(err.getMessage(), err.getStatus());
        } catch (Exception err) {
            status = HttpStatus.INTERNAL_SERVER_ERROR;
            message = err.getMessage();
            response.setError(status.getReasonPhrase());
            log.error(err.getMessage());
            throw new ErrorWithStatusException(err.getMessage(), status);
        }

        response.setStatus(status.value());
        response.setMessage(message);
        return ResponseEntity.status(status).body(response);
    }

    @Transactional
    public ResponseEntity<GlobalDTO<TalentDetailResponseDTO>> updateTalent(UpdateTalentRequestDTO request,
            MultipartFile talentPhotoFile,
            MultipartFile cvFile) {
        GlobalDTO<TalentDetailResponseDTO> response = new GlobalDTO<TalentDetailResponseDTO>();

        HttpStatus status = HttpStatus.OK;
        String message = "";

        log.info(messageUtil.get("log.success.request.received", "update talent", request.toString(),
                "anonymous"));

        try {
            if (request.getTalentId() == null) {
                throw new ErrorWithStatusException(
                        "talentId must not be null",
                        HttpStatus.BAD_REQUEST);
            }
            Optional<Talent> talent = talentRepository.findById(request.getTalentId());
            if (talent.isEmpty()) {
                throw new ErrorWithStatusException(
                        messageUtil.get("application.error.talent.not-found", request.getTalentId().toString()),
                        HttpStatus.NOT_FOUND);
            }

            if (request.getTalentName() != null) {
                talent.get().setTalentName(request.getTalentName());
            }
            if (request.getTalentAvailability() != null) {
                talent.get().setTalentAvailability(request.getTalentAvailability());
            }
            if (request.getTalentExperience() != null) {
                talent.get().setExperience(request.getTalentExperience());
            }
            if (request.getNip() != null) {
                talent.get().setEmployeeNumber(request.getNip());
            }
            if (request.getSex() != null) {
                talent.get().setGender(request.getSex());
            }
            if (request.getDob() != null) {
                talent.get().setBirthDate(LocalDate.parse(request.getDob(), DateTimeFormatter.ofPattern("yyyy-MM-dd"))
                        .atStartOfDay().atOffset(ZoneOffset.UTC));
            }
            if (request.getTalentDescription() != null) {
                talent.get().setTalentDescription(request.getTalentDescription());
            }
            if (request.getProjectCompleted() != null) {
                Optional<TalentMetadata> metadata = talentMetadataRepository.findByTalentId(talent.get().getTalentId());
                metadata.get().setTotalProjectCompleted(request.getProjectCompleted());
                talentMetadataRepository.save(metadata.get());
            }
            if (request.getEmail() != null) {
                talent.get().setEmail(request.getEmail());
            }
            if (request.getCellphone() != null) {
                talent.get().setCellphone(request.getCellphone());
            }
            if (request.getVideoUrl() != null) {
                talent.get().setBiographyVideoUrl(request.getVideoUrl());
            }

            if (request.getTalentStatusId() != null) {
                Optional<TalentStatus> talentStatus = talentStatusRepository.findById(request.getTalentStatusId());
                if (talentStatus.isEmpty()) {
                    throw new ErrorWithStatusException(
                            "talentStatusId: " + request.getTalentStatusId() + " is not found or invalid.",
                            HttpStatus.NOT_FOUND);
                }
                talent.get().setTalentStatus(talentStatus.get());
            }
            if (request.getTalentLevelId() != null) {
                Optional<TalentLevel> talentLevel = talentLevelRepository.findById(request.getTalentLevelId());
                if (talentLevel.isEmpty()) {
                    throw new ErrorWithStatusException(
                            "talentLevelId: " + request.getTalentLevelId() + " is not found or invalid.",
                            HttpStatus.NOT_FOUND);
                }
                talent.get().setTalentLevel(talentLevel.get());
            }
            if (request.getEmployeeStatusId() != null) {
                Optional<EmployeeStatus> employeeStatus = employeeStatusRepository
                        .findById(request.getEmployeeStatusId());
                if (employeeStatus.isEmpty()) {
                    throw new ErrorWithStatusException(
                            "employeeStatus: " + request.getEmployeeStatusId() + " is not found or invalid.",
                            HttpStatus.NOT_FOUND);
                }
                talent.get().setEmployeeStatus(employeeStatus.get());
            }

            if (talentPhotoFile != null) {
                if (!talentPhotoFile.isEmpty()) {
                    if (!minioService.getFileExtension(talentPhotoFile.getOriginalFilename()).toLowerCase()
                            .equals(".jpg")
                            && !minioService.getFileExtension(talentPhotoFile.getOriginalFilename()).toLowerCase()
                                    .equals(".jpeg")
                            && !minioService.getFileExtension(talentPhotoFile.getOriginalFilename()).toLowerCase()
                                    .equals(".png")) {

                        throw new ErrorWithStatusException(
                                "unsupported file extension: " + talentPhotoFile.getOriginalFilename()
                                        + ". only supports .jpg/.jpeg/.png.",
                                HttpStatus.NOT_FOUND);
                    } else {
                        String filename = minioService.generatedFilename("profile", talent.get().getTalentName(),
                                talent.get().getExperience(),
                                talent.get().getTalentLevel().getTalentLevelName(), talentPhotoFile);

                        minioService.updateFile(talent.get().getTalentPhotoFilename(), filename, talentPhotoFile);
                        talent.get().setTalentPhotoFilename(filename);

                    }

                } else {

                    if (minioService.fileExists(talent.get().getTalentPhotoFilename())) {
                        minioService.deleteFile(talent.get().getTalentPhotoFilename());
                        talent.get().setTalentPhotoFilename(null);
                    }

                }
            }
            if (cvFile != null) {
                if (!cvFile.isEmpty()) {
                    if (!minioService.getFileExtension(cvFile.getOriginalFilename()).toLowerCase()
                            .equals(".pdf")
                            && !minioService.getFileExtension(cvFile.getOriginalFilename()).toLowerCase()
                                    .equals(".docx")) {

                        throw new ErrorWithStatusException(
                                "unsupported file extension: " + cvFile.getOriginalFilename()
                                        + ". only supports .pdf/.docx.",
                                HttpStatus.NOT_FOUND);
                    } else {
                        String filename = minioService.generatedFilename("cv", talent.get().getTalentName(),
                                talent.get().getExperience(),
                                talent.get().getTalentLevel().getTalentLevelName(), cvFile);

                        minioService.updateFile(talent.get().getTalentCvFilename(), filename, cvFile);
                        talent.get().setTalentCvFilename(filename);
                    }
                } else {
                    if (minioService.fileExists(talent.get().getTalentCvFilename())) {
                        minioService.deleteFile(talent.get().getTalentCvFilename());
                        talent.get().setTalentCvFilename(null);
                    }
                }
            }

            talent.get().setLastModifiedBy("mrdevsAPI");
            talentRepository.save(talent.get());

            if (request.getPosition() != null) {
                List<TalentPosition> talentPositions = talentPositionRepository
                        .getTalentPositions(talent.get().getTalentId());
                if (talentPositions.size() > 0) {
                    talentPositionRepository.deleteByTalentId(request.getTalentId());
                }

                for (PositionCreateTalentRequestDTO position : request.getPosition()) {
                    TalentPosition talentPosition = new TalentPosition();
                    Optional<Position> positions = positionRepository.findById(position.getPositionId());
                    if (positions.isEmpty()) {
                        throw new ErrorWithStatusException(
                                "position: " + position.getPositionId() + " is not found or invalid.",
                                HttpStatus.NOT_FOUND);
                    } else {
                        talentPosition.setTalent(talent.get());
                        talentPosition.setPosition(positions.get());
                        talentPosition.setCreatedBy("mrdevsAPI");
                        talentPositionRepository.save(talentPosition);
                    }
                }
            }
            if (request.getSkillset() != null) {
                List<TalentSkillset> talentSkillsets = talentSkillsetRepository
                        .getTalentSkillsets(talent.get().getTalentId());
                if (talentSkillsets.size() > 0 || request.getSkillset().isEmpty()) {
                    for (TalentSkillset skillset : talentSkillsets) {
                        SkillsetCreateTalentRequestDTO requestSkillset = request.getSkillset().stream()
                                .filter(item -> item.getSkillId().equals(skillset.getSkillset().getSkillsetId()))
                                .findFirst().orElse(null);
                        if (requestSkillset == null) {
                            talentSkillsetRepository.delete(skillset);
                        }

                    }

                }

                for (SkillsetCreateTalentRequestDTO skillset : request.getSkillset()) {
                    Optional<Skillset> skillsets = skillsetRepository.findById(skillset.getSkillId());
                    if (skillsets.isEmpty()) {
                        throw new ErrorWithStatusException(
                                "skillset: " + skillset.getSkillId() + " is not found or invalid.",
                                HttpStatus.NOT_FOUND);
                    } else {
                        Optional<TalentSkillset> formerTalentSkillset = talentSkillsetRepository
                                .findBySkillsetIdTalent(talent.get().getTalentId(), skillset.getSkillId());

                        if (formerTalentSkillset.isEmpty()) {
                            TalentSkillset talentSkillset = TalentSkillset.builder()
                                    .id(TalentSkillsetId.builder().talentId(talent.get().getTalentId())
                                            .skillsetId(skillsets.get().getSkillsetId()).build())
                                    .talent(talent.get())
                                    .skillset(skillsets.get()).createdBy("mrdevsAPI").build();
                            talentSkillsetRepository.save(talentSkillset);
                        }

                    }
                }
            }

            Set<TalentWishlist> talentWhislists = talent.get().getTalentTalentWishlists();
            Integer totalRequested = 0;
            if (talentWhislists != null && !talentWhislists.isEmpty()) {
                for (TalentWishlist talentWishlist : talentWhislists) {
                    totalRequested += talentRequestRepository
                            .countByTalentWhislistId(talentWishlist.getTalentWishlistId());
                }
            }

            message = messageUtil.get("application.success.update.talent",
                    talent.get().getTalentName());
            response.setData(
                    new TalentDetailResponseDTO(talent.get(),
                            minioService.getPublicLink(talent.get().getTalentPhotoFilename()),
                            minioService.getPublicLink(talent.get().getTalentCvFilename()), totalRequested));
            log.info(message);

        } catch (ErrorWithStatusException err) {
            status = err.getStatus();
            message = err.getMessage();
            response.setError(err.getStatus().getReasonPhrase());
            log.error(err.getMessage());
            throw new ErrorWithStatusException(err.getMessage(), err.getStatus());
        } catch (Exception err) {
            status = HttpStatus.INTERNAL_SERVER_ERROR;
            message = err.getMessage();
            response.setError(status.getReasonPhrase());
            log.error(err.getMessage());
            throw new ErrorWithStatusException(err.getMessage(), status);
        }

        response.setStatus(status.value());
        response.setMessage(message);
        return ResponseEntity.status(status).body(response);
    }

}
