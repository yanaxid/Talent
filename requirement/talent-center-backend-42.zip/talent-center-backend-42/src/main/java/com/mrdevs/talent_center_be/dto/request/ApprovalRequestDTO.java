package com.mrdevs.talent_center_be.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ApprovalRequestDTO {

    @NotBlank(message = "action cannot be empty")
    private String action;

    @NotBlank(message = "talentRequestId cannot be empty")
    private String talentRequestId;

    private String rejectReason;
}
