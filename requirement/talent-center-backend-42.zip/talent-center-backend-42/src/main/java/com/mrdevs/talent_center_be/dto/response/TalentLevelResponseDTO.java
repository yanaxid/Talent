package com.mrdevs.talent_center_be.dto.response;

import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TalentLevelResponseDTO {
    private UUID talentLevelId;
    private String talentLevelName;
}
