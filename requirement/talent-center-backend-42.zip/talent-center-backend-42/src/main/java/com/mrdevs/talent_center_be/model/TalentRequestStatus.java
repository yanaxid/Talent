package com.mrdevs.talent_center_be.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

import java.time.OffsetDateTime;
import java.util.Set;
import java.util.UUID;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.UuidGenerator;

@Entity
@Getter
@Setter
@Table(name = "talent_request_status")
public class TalentRequestStatus {

    @Id
    @Column(nullable = false, updatable = false)
    @GeneratedValue
    @UuidGenerator
    private UUID talentRequestStatusId;

    @Column
    private String talentRequestStatusName;

    @Column
    private Boolean isActive;

    @Column(length = 50)
    private String createdBy;

    @Column
    private OffsetDateTime createdTime;

    @Column(length = 50)
    private String lastModifiedBy;

    @Column
    private OffsetDateTime lastModifiedTime;

    @OneToMany(mappedBy = "talentRequestStatus")
    private Set<TalentRequest> talentRequestStatusTalentRequests;

}
