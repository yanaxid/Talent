package com.mrdevs.talent_center_be.dto.response;

import java.util.UUID;

import com.mrdevs.talent_center_be.model.EmployeeStatus;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EmployeeStatusResponseDTO {
    private UUID employeeStatusId;
    private String employeeStatusName;

    public EmployeeStatusResponseDTO(EmployeeStatus employeeStatus) {
        this.employeeStatusId = employeeStatus.getEmployeeStatusId();
        this.employeeStatusName = employeeStatus.getEmployeeStatusName();
    }

}
