package com.mrdevs.talent_center_be.dto.response;

import java.util.UUID;

import com.mrdevs.talent_center_be.model.Skillset;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SkillsetResponseDTO {
    private UUID skillId;
    private String skillName;

    public SkillsetResponseDTO(Skillset skillset) {
        this.skillId = skillset.getSkillsetId();
        this.skillName = skillset.getSkillsetName();
    }
}
