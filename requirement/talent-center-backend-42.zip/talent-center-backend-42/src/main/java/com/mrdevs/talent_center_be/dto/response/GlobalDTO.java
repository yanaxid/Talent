package com.mrdevs.talent_center_be.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class GlobalDTO<T> {
    private int status;
    private String message;
    private String error;
    private T data;

    public GlobalDTO(int status, String message, T data) {
        this.status = status;
        this.message = message;
        this.data = data;
    }

    public GlobalDTO(int status, String message, String error) {
        this.status = status;
        this.message = message;
        this.error = error;
    }

}
