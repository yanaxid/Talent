package com.mrdevs.talent_center_be.dto.request;

import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TalentFilterRequestDTO {
    private String talentName;
    private UUID talentStatusId;
    private UUID employeeStatusId;
    private String talentAvailability;
    private Integer talentExperience;
    private String experienceRange;
    private UUID talentLevelId;
    private String positionName;
    private String email;
    private String cellphone;
    private String skillName;
    private String keyword;

}
