package com.mrdevs.talent_center_be.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

import java.time.OffsetDateTime;
import java.util.Set;
import java.util.UUID;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.UuidGenerator;

@Entity
@Getter
@Setter
@Table(name = "client")
public class Client {

    @Id
    @Column(nullable = false, updatable = false)
    @GeneratedValue
    @UuidGenerator
    private UUID clientId;

    @Column
    private String clientName;

    @Column
    private String gender;

    @Column
    private OffsetDateTime birthDate;

    @Column(length = 100)
    private String email;

    @Column(length = 100)
    private String agencyName;

    @Column
    private String agencyAddress;

    @Column
    private Boolean isActive;

    @Column
    private String createdBy;

    @Column
    private OffsetDateTime createdTime;

    @Column
    private String lastModifiedBy;

    @Column
    private OffsetDateTime lastModifiedTime;

    @Column
    private String sex;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "client_position_id")
    private ClientPosition clientPosition;

    @OneToMany(mappedBy = "client")
    private Set<TalentWishlist> clientTalentWishlists;

}
