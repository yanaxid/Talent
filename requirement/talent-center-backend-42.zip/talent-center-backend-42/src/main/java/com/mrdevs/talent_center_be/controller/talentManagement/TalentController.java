package com.mrdevs.talent_center_be.controller.talentManagement;

import java.util.List;
import java.util.UUID;

import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.SortDefault;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.mrdevs.talent_center_be.dto.request.ApprovalRequestDTO;
import com.mrdevs.talent_center_be.dto.request.CreateTalentRequestDTO;
import com.mrdevs.talent_center_be.dto.request.TalentApprovalFilterRequestDTO;
import com.mrdevs.talent_center_be.dto.request.TalentFilterRequestDTO;
import com.mrdevs.talent_center_be.dto.request.UpdateTalentRequestDTO;
import com.mrdevs.talent_center_be.dto.response.GlobalDTO;
import com.mrdevs.talent_center_be.dto.response.GlobalListDTO;
import com.mrdevs.talent_center_be.dto.response.TalentApprovalResponseDTO;
import com.mrdevs.talent_center_be.dto.response.TalentDetailResponseDTO;
import com.mrdevs.talent_center_be.dto.response.TalentResponseDTO;
import com.mrdevs.talent_center_be.exception.ErrorWithStatusException;
import com.mrdevs.talent_center_be.service.TalentService;

import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

@Tag(name = "Talent", description = "Talent Management APIs")
@RestController
@RequestMapping("/talent-management")
@RequiredArgsConstructor
public class TalentController {

    private final TalentService talentService;

    @GetMapping("/talents")
    public ResponseEntity<GlobalListDTO<List<TalentResponseDTO>>> getTalents(
            @PageableDefault(page = 0, size = 10) @SortDefault.SortDefaults({
                    @SortDefault(sort = "experience", direction = Direction.DESC),
                    @SortDefault(sort = "talentLevel.talentLevelName", direction = Direction.ASC),
                    @SortDefault(sort = "talentName", direction = Direction.ASC) }) Pageable page,
            @ModelAttribute TalentFilterRequestDTO requestFilter) {
        return talentService.getTalents(page, requestFilter);
    }

    @PostMapping(path = "/talents", consumes = { MediaType.APPLICATION_JSON_VALUE,
            MediaType.MULTIPART_FORM_DATA_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
    public ResponseEntity<GlobalDTO<TalentDetailResponseDTO>> createTalent(
            @RequestPart("data") CreateTalentRequestDTO request,
            @RequestPart(value = "talentPhotoFile", required = false) MultipartFile talentPhotoFile,
            @RequestPart(value = "cvFile", required = false) MultipartFile cvFile) {
        try {
            return talentService.createTalent(request, talentPhotoFile, cvFile);
        } catch (ErrorWithStatusException err) {
            GlobalDTO<TalentDetailResponseDTO> response = new GlobalDTO<TalentDetailResponseDTO>();
            response.setError(err.getStatus().getReasonPhrase());
            response.setStatus(err.getStatus().value());
            response.setMessage(err.getMessage());
            return ResponseEntity.status(err.getStatus()).body(response);
        }
    }

    @PutMapping(path = "/talents", consumes = { MediaType.APPLICATION_JSON_VALUE,
            MediaType.MULTIPART_FORM_DATA_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
    public ResponseEntity<GlobalDTO<TalentDetailResponseDTO>> updateTalent(
            @RequestPart("data") UpdateTalentRequestDTO request,
            @RequestPart(value = "talentPhotoFile", required = false) MultipartFile talentPhotoFile,
            @RequestPart(value = "cvFile", required = false) MultipartFile cvFile) {

        try {
            return talentService.updateTalent(request, talentPhotoFile, cvFile);
        } catch (ErrorWithStatusException err) {
            GlobalDTO<TalentDetailResponseDTO> response = new GlobalDTO<TalentDetailResponseDTO>();
            response.setError(err.getStatus().getReasonPhrase());
            response.setStatus(err.getStatus().value());
            response.setMessage(err.getMessage());
            return ResponseEntity.status(err.getStatus()).body(response);
        }
    }

    @GetMapping("/talents/{talentId}")
    public ResponseEntity<GlobalDTO<TalentDetailResponseDTO>> getTalentById(
            @PathVariable(name = "talentId") UUID talentId) {
        return talentService.getTalentById(talentId);
    }

    @GetMapping("/talent-approvals")
    public ResponseEntity<GlobalListDTO<List<TalentApprovalResponseDTO>>> getTalentApprovals(
            @PageableDefault(page = 0, size = 10, sort = "requestDate", direction = Direction.DESC) Pageable page,
            @ModelAttribute TalentApprovalFilterRequestDTO requestFilter) {
        return talentService.getTalentApprovals(page, requestFilter);
    }

    @PutMapping(path = "/talent-approvals", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GlobalDTO<TalentApprovalResponseDTO>> updateTalentApprovalStatus(
            @RequestBody ApprovalRequestDTO request) {
        try {
            return talentService.updateTalentApprovalStatus(request);
        } catch (ErrorWithStatusException err) {
            GlobalDTO<TalentApprovalResponseDTO> response = new GlobalDTO<TalentApprovalResponseDTO>();
            response.setError(err.getStatus().getReasonPhrase());
            response.setStatus(err.getStatus().value());
            response.setMessage(err.getMessage());
            return ResponseEntity.status(err.getStatus()).body(response);
        }
    }

}
