package com.mrdevs.talent_center_be.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

import java.time.OffsetDateTime;
import java.util.Set;
import java.util.UUID;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.UuidGenerator;

@Entity
@Getter
@Setter
@Table(name = "talent_wishlist")
public class TalentWishlist {

    @Id
    @Column(name = "talent_wishlist_id", nullable = false, updatable = false)
    @GeneratedValue
    @UuidGenerator
    private UUID talentWishlistId;

    @Column(name = "wishlist_date", nullable = false)
    private OffsetDateTime wishlistDate;

    @Column(name = "is_active")
    private Boolean isActive;

    @Column(name = "created_by", length = 50)
    private String createdBy;

    @Column(name = "created_time")
    private OffsetDateTime createdTime;

    @Column(name = "last_modified_by", length = 50)
    private String lastModifiedBy;

    @Column(name = "last_modified_time")
    private OffsetDateTime lastModifiedTime;

    @OneToMany(mappedBy = "talentWishlist")
    private Set<TalentRequest> talentWishlistTalentRequests;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "client_id", nullable = false)
    private Client client;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "talent_id", nullable = false)
    private Talent talent;

}
