package com.mrdevs.talent_center_be.dto.response;

import java.time.format.DateTimeFormatter;
import java.util.stream.Collectors;

import com.mrdevs.talent_center_be.model.Talent;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class TalentDetailResponseDTO extends TalentResponseDTO {
    private String nip;
    private Character sex;
    private String dob;
    private String talentDescription;
    private String cv;
    private Integer projectCompleted;
    private Integer totalRequested;
    private String email;
    private String cellphone;
    private String videoUrl;

    public TalentDetailResponseDTO(Talent talent, String talentPhotoUrl, String cvUrl, Integer totalRequested) {
        super(talent, talentPhotoUrl);
        this.nip = talent.getEmployeeNumber();
        this.sex = talent.getGender();
        this.dob = talent.getBirthDate() != null ? talent.getBirthDate().format(DateTimeFormatter.ISO_LOCAL_DATE)
                : null;
        this.talentDescription = talent.getTalentDescription();
        this.cv = cvUrl;
        this.projectCompleted = talent.getTalentTalentMetadatas() != null
                && !talent.getTalentTalentMetadatas().isEmpty()
                        ? talent.getTalentTalentMetadatas().stream().collect(Collectors.toList()).get(0)
                                .getTotalProjectCompleted()
                        : 0;
        this.totalRequested = totalRequested;
        this.email = talent.getEmail();
        this.cellphone = talent.getCellphone();
        this.videoUrl = talent.getBiographyVideoUrl();
    }

}
