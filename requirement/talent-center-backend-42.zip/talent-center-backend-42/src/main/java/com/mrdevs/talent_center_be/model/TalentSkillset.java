package com.mrdevs.talent_center_be.model;

import java.time.OffsetDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.MapsId;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "talent_skillset")
public class TalentSkillset {

    @EmbeddedId
    private TalentSkillsetId id;

    @Column(name = "created_by", nullable = false, updatable = false, length = 50)
    private String createdBy;

    @Column(name = "created_time")
    private OffsetDateTime createdTime;

    @Column(name = "last_modified_by", length = 50)
    private String lastModifiedBy;

    @Column(name = "last_modified_time")
    private OffsetDateTime lastModifiedTime;

    @MapsId("skillsetId")
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "skillset_id", nullable = false)
    private Skillset skillset;

    @MapsId("talentId")
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "talent_id", nullable = false)
    private Talent talent;

    @PrePersist
    protected void onCreate() {
        this.createdTime = OffsetDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        this.lastModifiedTime = OffsetDateTime.now();
    }

}
