package com.mrdevs.talent_center_be.exception;

import org.springframework.http.HttpStatus;

import lombok.Getter;

@Getter
public class ErrorWithStatusException extends RuntimeException {

    private HttpStatus status;

    public ErrorWithStatusException(String message, HttpStatus status) {
        super(message);
        this.status = status;
    }

}
