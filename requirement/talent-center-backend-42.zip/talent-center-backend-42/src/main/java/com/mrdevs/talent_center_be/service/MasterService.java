package com.mrdevs.talent_center_be.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.mrdevs.talent_center_be.dto.response.EmployeeStatusResponseDTO;
import com.mrdevs.talent_center_be.dto.response.GlobalDTO;
import com.mrdevs.talent_center_be.dto.response.PositionResponseDTO;
import com.mrdevs.talent_center_be.dto.response.SkillsetResponseDTO;
import com.mrdevs.talent_center_be.dto.response.TalentLevelResponseDTO;
import com.mrdevs.talent_center_be.dto.response.TalentStatusResponseDTO;
import com.mrdevs.talent_center_be.exception.ErrorWithStatusException;
import com.mrdevs.talent_center_be.model.EmployeeStatus;
import com.mrdevs.talent_center_be.model.Position;
import com.mrdevs.talent_center_be.model.Skillset;
import com.mrdevs.talent_center_be.model.TalentLevel;
import com.mrdevs.talent_center_be.model.TalentStatus;
import com.mrdevs.talent_center_be.repository.EmployeeStatusRepository;
import com.mrdevs.talent_center_be.repository.PositionRepository;
import com.mrdevs.talent_center_be.repository.SkillsetRepository;
import com.mrdevs.talent_center_be.repository.TalentLevelRepository;
import com.mrdevs.talent_center_be.repository.TalentStatusRepository;

import lib.i18n.utility.MessageUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class MasterService {
    private final MessageUtil messageUtil;
    private final EmployeeStatusRepository employeeStatusRepository;
    private final TalentStatusRepository talentStatusRepository;
    private final TalentLevelRepository talentLevelRepository;
    private final PositionRepository positionRepository;
    private final SkillsetRepository skillsetRepository;

    public ResponseEntity<GlobalDTO<List<EmployeeStatusResponseDTO>>> getEmployeeStatuses() {
        GlobalDTO<List<EmployeeStatusResponseDTO>> response = new GlobalDTO<List<EmployeeStatusResponseDTO>>();

        HttpStatus status = HttpStatus.OK;
        String message = "";

        log.info(messageUtil.get("log.success.request.received", "get employee status", "", "anonymous"));

        try {
            List<EmployeeStatus> employeeStatus = employeeStatusRepository.findAll();

            List<EmployeeStatusResponseDTO> responseData = employeeStatus.stream()
                    .map(item -> new EmployeeStatusResponseDTO(item)).collect(Collectors.toList());

            if (responseData.isEmpty()) {
                throw new ErrorWithStatusException(messageUtil.get("application.error.employee-status.not-found"),
                        HttpStatus.NOT_FOUND);
            }

            message = messageUtil.get("application.success.employee-status.found");
            response.setData(responseData);
            log.info(message);

        } catch (ErrorWithStatusException err) {
            status = err.getStatus();
            message = err.getMessage();
            response.setError(err.getStatus().getReasonPhrase());
            log.error(err.getMessage());
        } catch (Exception err) {
            status = HttpStatus.INTERNAL_SERVER_ERROR;
            message = err.getMessage();
            response.setError(status.getReasonPhrase());
            log.error(err.getMessage());
        }

        response.setStatus(status.value());
        response.setMessage(message);
        return ResponseEntity.status(status).body(response);
    }

    public ResponseEntity<GlobalDTO<List<TalentStatusResponseDTO>>> getTalentStatuses() {
        GlobalDTO<List<TalentStatusResponseDTO>> response = new GlobalDTO<List<TalentStatusResponseDTO>>();

        HttpStatus status = HttpStatus.OK;
        String message = "";

        log.info(messageUtil.get("log.success.request.received", "get talent status", "", "anonymous"));

        try {
            List<TalentStatus> talentStatus = talentStatusRepository.findAll();

            List<TalentStatusResponseDTO> responseData = talentStatus.stream()
                    .map(item -> new TalentStatusResponseDTO(item.getTalentStatusId(), item.getTalentStatusName()))
                    .collect(Collectors.toList());

            if (responseData.isEmpty()) {
                throw new ErrorWithStatusException(messageUtil.get("application.error.talent-status.not-found"),
                        HttpStatus.NOT_FOUND);
            }

            message = messageUtil.get("application.success.talent-status.found");
            response.setData(responseData);
            log.info(message);

        } catch (ErrorWithStatusException err) {
            status = err.getStatus();
            message = err.getMessage();
            response.setError(err.getStatus().getReasonPhrase());
            log.error(err.getMessage());
        } catch (Exception err) {
            status = HttpStatus.INTERNAL_SERVER_ERROR;
            message = err.getMessage();
            response.setError(status.getReasonPhrase());
            log.error(err.getMessage());
        }

        response.setStatus(status.value());
        response.setMessage(message);
        return ResponseEntity.status(status).body(response);
    }

    public ResponseEntity<GlobalDTO<List<TalentLevelResponseDTO>>> getTalentLevels() {
        GlobalDTO<List<TalentLevelResponseDTO>> response = new GlobalDTO<List<TalentLevelResponseDTO>>();

        HttpStatus status = HttpStatus.OK;
        String message = "";

        log.info(messageUtil.get("log.success.request.received", "get talent level", "", "anonymous"));

        try {
            List<TalentLevel> talentLevels = talentLevelRepository.findAll();

            List<TalentLevelResponseDTO> responseData = talentLevels.stream()
                    .map(item -> new TalentLevelResponseDTO(item.getTalentLevelId(), item.getTalentLevelName()))
                    .collect(Collectors.toList());

            if (responseData.isEmpty()) {
                throw new ErrorWithStatusException(messageUtil.get("application.error.talent-level.not-found"),
                        HttpStatus.NOT_FOUND);
            }

            message = messageUtil.get("application.success.talent-level.found");
            response.setData(responseData);
            log.info(message);

        } catch (ErrorWithStatusException err) {
            status = err.getStatus();
            message = err.getMessage();
            response.setError(err.getStatus().getReasonPhrase());
            log.error(err.getMessage());
        } catch (Exception err) {
            status = HttpStatus.INTERNAL_SERVER_ERROR;
            message = err.getMessage();
            response.setError(status.getReasonPhrase());
            log.error(err.getMessage());
        }

        response.setStatus(status.value());
        response.setMessage(message);
        return ResponseEntity.status(status).body(response);
    }

    public ResponseEntity<GlobalDTO<List<PositionResponseDTO>>> getPositions() {
        GlobalDTO<List<PositionResponseDTO>> response = new GlobalDTO<List<PositionResponseDTO>>();

        HttpStatus status = HttpStatus.OK;
        String message = "";

        log.info(messageUtil.get("log.success.request.received", "get position", "", "anonymous"));

        try {
            List<Position> positions = positionRepository.findAll();

            List<PositionResponseDTO> responseData = positions.stream()
                    .map(item -> new PositionResponseDTO(item.getPositionId(), item.getPositionName()))
                    .collect(Collectors.toList());

            if (responseData.isEmpty()) {
                throw new ErrorWithStatusException(messageUtil.get("application.error.position.not-found"),
                        HttpStatus.NOT_FOUND);
            }

            message = messageUtil.get("application.success.position.found");
            response.setData(responseData);
            log.info(message);

        } catch (ErrorWithStatusException err) {
            status = err.getStatus();
            message = err.getMessage();
            response.setError(err.getStatus().getReasonPhrase());
            log.error(err.getMessage());
        } catch (Exception err) {
            status = HttpStatus.INTERNAL_SERVER_ERROR;
            message = err.getMessage();
            response.setError(status.getReasonPhrase());
            log.error(err.getMessage());
        }

        response.setStatus(status.value());
        response.setMessage(message);
        return ResponseEntity.status(status).body(response);
    }

    public ResponseEntity<GlobalDTO<List<SkillsetResponseDTO>>> getSkillsets() {
        GlobalDTO<List<SkillsetResponseDTO>> response = new GlobalDTO<List<SkillsetResponseDTO>>();

        HttpStatus status = HttpStatus.OK;
        String message = "";

        log.info(messageUtil.get("log.success.request.received", "get skillset", "", "anonymous"));

        try {
            List<Skillset> skillsets = skillsetRepository.findAll();

            List<SkillsetResponseDTO> responseData = skillsets.stream()
                    .map(item -> new SkillsetResponseDTO(item.getSkillsetId(), item.getSkillsetName()))
                    .collect(Collectors.toList());

            if (responseData.isEmpty()) {
                throw new ErrorWithStatusException(messageUtil.get("application.error.skillset.not-found"),
                        HttpStatus.NOT_FOUND);
            }

            message = messageUtil.get("application.success.skillset.found");
            response.setData(responseData);
            log.info(message);

        } catch (ErrorWithStatusException err) {
            status = err.getStatus();
            message = err.getMessage();
            response.setError(err.getStatus().getReasonPhrase());
            log.error(err.getMessage());
        } catch (Exception err) {
            status = HttpStatus.INTERNAL_SERVER_ERROR;
            message = err.getMessage();
            response.setError(status.getReasonPhrase());
            log.error(err.getMessage());
        }

        response.setStatus(status.value());
        response.setMessage(message);
        return ResponseEntity.status(status).body(response);
    }

}
