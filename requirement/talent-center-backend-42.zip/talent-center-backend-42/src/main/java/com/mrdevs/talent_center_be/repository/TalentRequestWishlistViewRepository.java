package com.mrdevs.talent_center_be.repository;

import com.mrdevs.talent_center_be.model.TalentRequestWishlistView;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

@Repository
public interface TalentRequestWishlistViewRepository extends JpaRepository<TalentRequestWishlistView, UUID> {
}
