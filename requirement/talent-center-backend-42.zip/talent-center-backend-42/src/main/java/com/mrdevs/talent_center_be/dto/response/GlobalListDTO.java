package com.mrdevs.talent_center_be.dto.response;

import org.springframework.data.domain.Pageable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class GlobalListDTO<T> extends GlobalDTO<T> {
    private long total;
    private Pageable page;
}
