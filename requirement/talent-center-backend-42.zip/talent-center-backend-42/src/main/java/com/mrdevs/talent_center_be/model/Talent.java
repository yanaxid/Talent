package com.mrdevs.talent_center_be.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;

import java.time.OffsetDateTime;
import java.util.Set;
import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.UuidGenerator;

@Entity
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "talent")
public class Talent {

    @Id
    @Column(name = "talent_id", nullable = false, updatable = false)
    @GeneratedValue
    @UuidGenerator
    private UUID talentId;

    @Column(name = "talent_name")
    private String talentName;

    @Column(name = "talent_photo_filename")
    private String talentPhotoFilename;

    @Column(name = "employee_number", length = 50)
    private String employeeNumber;

    @Column(name = "gender")
    private Character gender;

    @Column(name = "birth_date")
    private OffsetDateTime birthDate;

    @Column(name = "talent_description", columnDefinition = "text")
    private String talentDescription;

    @Column(name = "talent_cv_filename")
    private String talentCvFilename;

    @Column(name = "experience")
    private Integer experience;

    @Column(name = "email", length = 100)
    private String email;

    @Column(name = "cellphone", length = 20)
    private String cellphone;

    @Column(name = "biography_video_url")
    private String biographyVideoUrl;

    @Column(name = "is_add_to_list_enable")
    private Boolean isAddToListEnable;

    @Column(name = "talent_availability")
    private Boolean talentAvailability;

    @Column(name = "isActive")
    private Boolean isActive;

    @Column(name = "created_by", length = 50)
    private String createdBy;

    @Column(name = "created_time")
    private OffsetDateTime createdTime;

    @Column(name = "last_modified_by", length = 50)
    private String lastModifiedBy;

    @Column(name = "last_modified_time")
    private OffsetDateTime lastModifiedTime;

    // unused
    @Column(name = "sex")
    private String sex;

    @Column(name = "talent_cv_url", columnDefinition = "text")
    private String talentCvUrl;

    @Column(name = "talent_photo_url", columnDefinition = "text")
    private String talentPhotoUrl;

    @Column(name = "total_project_completed")
    private Integer totalProjectCompleted;
    // end unused

    @OneToMany(mappedBy = "talent")
    private Set<TalentMetadata> talentTalentMetadatas;

    @OneToMany(mappedBy = "talent")
    private Set<TalentPosition> talentTalentPositions;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "employee_status_id")
    private EmployeeStatus employeeStatus;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "talent_level_id")
    private TalentLevel talentLevel;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "talent_status_id")
    private TalentStatus talentStatus;

    @OneToMany(mappedBy = "talent")
    private Set<TalentSkillset> talentTalentSkillsets;

    @OneToMany(mappedBy = "talent")
    private Set<TalentWishlist> talentTalentWishlists;

    @PrePersist
    protected void onCreate() {
        this.createdTime = OffsetDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        this.lastModifiedTime = OffsetDateTime.now();
    }

}
